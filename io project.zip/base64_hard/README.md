# Base64 Hard
Multi-layer encoded file.
