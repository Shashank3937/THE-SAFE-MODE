Decode → inspect file.
