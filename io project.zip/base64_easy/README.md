# Base64 Easy
Decode artifact.txt and submit flag{secret easy message}.
