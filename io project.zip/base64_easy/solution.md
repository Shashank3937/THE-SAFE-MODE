Decoded: secret easy message
Flag: flag{secret easy message}
