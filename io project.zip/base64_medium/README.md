# Base64 Medium
Base64 then ROT13.
