ROT13 → Base64 → plaintext.
